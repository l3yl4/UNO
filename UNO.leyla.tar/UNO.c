#include <stdio.h>

#include "cartas.h"
#include"jugadores.h"
#include "partida.h"

int main()
{
    //marta: falta declarar la variable que almacena toda la partida
    tUNO p;
    
}



