#include <stdio.h>
#include "jugadores.h"
#include "cartas.h"

/*int main ()
{
    
}*/

void tirada(){
    
}; // función que determina si puedes tirar o no, en caso de que sí se pueda determina las posibilidades
void mostrar_nombre(){
    
}; //imprimir por patalla el nombre de los jugadores
