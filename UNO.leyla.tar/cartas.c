#include <stdio.h>
#include "cartas.h"
#include "colores.h"

/*int main ()
{
    
}*/

void mostrar_cartas(tbaraja b){
    
} //funcion que muestra las cartas
void repartir_aleatoriamente(){
    
} // función que reparte las cartas
